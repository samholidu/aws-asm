# Author: Samarth Kanungo
# Resource: AWS Secret Manager
# Description: This package helps to get the secret from aws secret manager
# Last Modified: Fri Sep 10 22:31:47 CEST 2021

import boto3
import ast
import sys
import base64
from botocore.exceptions import ClientError

def secret_manager_client(region_name):
    session = boto3.session.Session()
    client = session.client(
        service_name='secretsmanager',
        region_name=region_name
    )
    return client


def FetchSecret(aws_secret_key):
    resp_secret = ""
    secret_name = aws_secret_key
    region_name = "eu-west-1"
    client = secret_manager_client(region_name)

    try:
        get_secret_value_response = client.get_secret_value(
            SecretId=secret_name
        )
    except ClientError as e:
        if e.response['Error']['Code'] == 'DecryptionFailureException':
            # Secrets Manager can't decrypt the protected secret text using the provided KMS key.
            # Deal with the exception here, and/or rethrow at your discretion.
            raise e
        elif e.response['Error']['Code'] == 'InternalServiceErrorException':
            # An error occurred on the server side.
            # Deal with the exception here, and/or rethrow at your discretion.
            raise e
        elif e.response['Error']['Code'] == 'InvalidParameterException':
            # You provided an invalid value for a parameter.
            # Deal with the exception here, and/or rethrow at your discretion.
            raise e
        elif e.response['Error']['Code'] == 'InvalidRequestException':
            # You provided a parameter value that is not valid for the current state of the resource.
            # Deal with the exception here, and/or rethrow at your discretion.
            raise e
        elif e.response['Error']['Code'] == 'ResourceNotFoundException':
            # We can't find the resource that you asked for.
            # Deal with the exception here, and/or rethrow at your discretion.
            raise e
    else:
        # Decrypts secret using the associated KMS CMK.
        # Depending on whether the secret is a string or binary, one of these fields will be populated.
        if 'SecretString' in get_secret_value_response:
            secret = get_secret_value_response['SecretString']
            resp_secret = ast.literal_eval(secret)[secret_name]

        else:
            decoded_binary_secret = base64.b64decode(get_secret_value_response['SecretBinary'])
            resp_secret = decoded_binary_secret

    return resp_secret